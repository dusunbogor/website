import Navbar from '../components/Navbar';
import Section from '../components/Section';
import Head from 'next/head';
import styles from '../styles/Gallery.module.css';

const images = [
  { src: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=cover&w=600&q=80', alt: 'Dusun Bogor Scenery' },
  { src: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=cover&w=600&q=80', alt: 'Community Event' },
  { src: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=cover&w=600&q=80', alt: 'Youth Activities' },
  { src: 'https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=cover&w=600&q=80', alt: 'Cultural Performance' },
];

export default function Gallery() {
  return (
    <>
      <Head>
        <title>Gallery | Dusun Bogor</title>
      </Head>
      <Navbar />
      <main style={{ maxWidth: 900, margin: '2rem auto', padding: '0 1rem' }}>
        <Section delay={0.1}>
          <h1>Gallery</h1>
          <p>
            Explore the beauty and spirit of Dusun Bogor through our gallery.
          </p>
        </Section>
        <div className={styles.grid}>
          {images.map((img, idx) => (
            <Section key={img.src} delay={0.2 + idx * 0.15} className={styles.imageContainer}>
              <img src={img.src} alt={img.alt} className={styles.img} />
              <div className={styles.caption}>{img.alt}</div>
            </Section>
          ))}
        </div>
      </main>
    </>
  );
}