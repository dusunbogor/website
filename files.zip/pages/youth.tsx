import Navbar from '../components/Navbar';
import Section from '../components/Section';
import Head from 'next/head';

export default function Youth() {
  return (
    <>
      <Head>
        <title>Youth Organization | Dusun Bogor</title>
      </Head>
      <Navbar />
      <main style={{ maxWidth: 850, margin: '2rem auto', padding: '0 1rem' }}>
        <Section delay={0.1}>
          <h1>Youth Organization</h1>
          <p>
            The Dusun Bogor Youth Organization empowers young people to be creative, responsible, and active citizens. Our activities encourage leadership, teamwork, and service to the community.
          </p>
        </Section>
        <Section delay={0.3}>
          <h2>Activities</h2>
          <ul>
            <li>Environmental campaigns and clean-ups</li>
            <li>Cultural performances and workshops</li>
            <li>Sports tournaments and outdoor adventures</li>
            <li>Entrepreneurship and digital skills training</li>
          </ul>
        </Section>
        <Section delay={0.5}>
          <h2>Join Us!</h2>
          <p>
            If you are a youth who wants to make a positive impact, join our organization and shape the future of Dusun Bogor together!
          </p>
        </Section>
      </main>
    </>
  );
}