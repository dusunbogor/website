import Navbar from '../components/Navbar';
import Section from '../components/Section';
import Head from 'next/head';
import styles from '../styles/Home.module.css';

export default function Home() {
  return (
    <>
      <Head>
        <title>Dusun Bogor</title>
      </Head>
      <Navbar />
      <main className={styles.main}>
        <Section delay={0.1} className={styles.hero}>
          <h1>Welcome to Dusun Bogor</h1>
          <p>
            Discover the vibrant spirit, unity, and beautiful scenery of Dusun Bogor. Enjoy our interactive journey!
          </p>
        </Section>
        <Section delay={0.3} className={styles.feature}>
          <h2>Our Culture</h2>
          <p>
            Dusun Bogor is a community rich in tradition and togetherness. We celebrate our heritage through shared values and community events.
          </p>
        </Section>
        <Section delay={0.5} className={styles.feature}>
          <h2>Nature & Environment</h2>
          <p>
            Surrounded by lush greenery and scenic views, Dusun Bogor offers peace and natural beauty for all who visit.
          </p>
        </Section>
        <Section delay={0.7} className={styles.feature}>
          <h2>Dynamic Youth Organization</h2>
          <p>
            Empowering the next generation through creativity, leadership, and community service.
          </p>
        </Section>
      </main>
    </>
  );
}