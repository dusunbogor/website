import Navbar from '../components/Navbar';
import Section from '../components/Section';
import Head from 'next/head';

export default function About() {
  return (
    <>
      <Head>
        <title>About Us | Dusun Bogor</title>
      </Head>
      <Navbar />
      <main style={{ maxWidth: 850, margin: '2rem auto', padding: '0 1rem' }}>
        <Section delay={0.1}>
          <h1>About Dusun Bogor</h1>
          <p>
            Dusun Bogor is a close-knit community where harmony, cooperation, and tradition flourish. Our residents take pride in our shared history, beautiful landscapes, and active participation in cultural and social events.
          </p>
        </Section>
        <Section delay={0.3}>
          <h2>Our Vision</h2>
          <p>
            To create a progressive, inclusive, and sustainable village that preserves cultural heritage while embracing innovation.
          </p>
        </Section>
        <Section delay={0.5}>
          <h2>Our Mission</h2>
          <ul>
            <li>Promote unity and togetherness among residents</li>
            <li>Support youth development and leadership</li>
            <li>Preserve cultural values and the environment</li>
            <li>Encourage social entrepreneurship and creativity</li>
          </ul>
        </Section>
      </main>
    </>
  );
}