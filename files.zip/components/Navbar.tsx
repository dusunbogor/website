import Link from 'next/link';
import styles from './Navbar.module.css';

const navItems = [
  { name: 'Home', href: '/' },
  { name: 'About Us', href: '/about' },
  { name: 'Youth Organization', href: '/youth' },
  { name: 'Gallery', href: '/gallery' },
];

export default function Navbar() {
  return (
    <nav className={styles.nav}>
      <div className={styles.logo}>Dusun Bogor</div>
      <ul className={styles.menu}>
        {navItems.map(item => (
          <li key={item.name}>
            <Link href={item.href}>{item.name}</Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}